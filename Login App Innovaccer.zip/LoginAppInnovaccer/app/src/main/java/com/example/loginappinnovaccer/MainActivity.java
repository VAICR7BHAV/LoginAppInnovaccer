package com.example.loginappinnovaccer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

public class MainActivity extends AppCompatActivity
{
    String visitor_name,visitor_email,visitor_phone,designation,
            host_name,host_email,host_phone;
    boolean isHost;
    TextView name_tv;
    TextView email_tv;
    TextView phone_tv;
    Button submit;
    Spinner desig;

    public void GetData(View view)
    {
        name_tv=(TextView)findViewById(R.id.NAME_TV);
        email_tv=(TextView)findViewById(R.id.EMAIL_TV);
        phone_tv=(TextView)findViewById(R.id.PHONE_Tv);

        desig=(Spinner)findViewById(R.id.designation_spinner);
        designation=desig.getSelectedItem().toString();
        submit=(Button)findViewById(R.id.submit);
        //Log.d("abcde",name+email+phone+designation);
        if(designation.equalsIgnoreCase("HOST"))
        {
            host_name=name_tv.getText().toString();
            host_email=email_tv.getText().toString();
            host_phone=phone_tv.getText().toString();
            Toast.makeText(getApplicationContext(),
                    host_name+" is the new host" ,
                    Toast.LENGTH_SHORT).show();
            isHost=true;
        }
        else if(isHost)
        {
            visitor_name=name_tv.getText().toString();
            visitor_email=email_tv.getText().toString();
            visitor_phone=phone_tv.getText().toString();
            Toast.makeText(getApplicationContext(),
                    visitor_name+" is the new visitor" ,
                    Toast.LENGTH_SHORT).show();
            Date currentTime = Calendar.getInstance().getTime();
            Log.d("abcde","Timestamp is"+currentTime);
            Intent emailIntent = new Intent(Intent.ACTION_SEND);
            String[] TO = {host_email};
            emailIntent.setData(Uri.parse("mailto:"));
            emailIntent.setType("text/plain");
            emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
            emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Your subject");
            emailIntent.putExtra(Intent.EXTRA_TEXT, "Email message goes here");
            try {
                startActivity(Intent.createChooser(emailIntent, "Send mail..."));
                finish();
                Log.d("abcde", "email_sent");
            } catch (android.content.ActivityNotFoundException ex) {
                Toast.makeText(MainActivity.this,
                        "There is no email client installed.", Toast.LENGTH_SHORT).show();
            }
        }
        else
        {
            Toast.makeText(getApplicationContext(),
                    visitor_name+" Please wait for the host" ,
                    Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
